#Importing Python libraries
import uuid

def get_uuid ():
    uuidFour = uuid.uuid4()
    print (uuidFour)
    return uuidFour
